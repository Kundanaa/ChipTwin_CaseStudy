#pragma once

// // UART Configuration
// #define TX_PIN 17
// #define RX_PIN 16
// #define UART_NUM UART_NUM_2
// #define BUF_SIZE 1024
#define RX_PIN 1  // Wokwi's virtual UART1 RX
#define TX_PIN 3  // Not used for receiver
#define BUF_SIZE 1024
#define UART_NUM UART_NUM_1