#ifndef TASKS_H
#define TASKS_H

void tx_task(void *pvParam);
void rx_task(void *pvParam);

#endif
